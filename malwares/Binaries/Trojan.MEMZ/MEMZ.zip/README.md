# MEMZ
memz trojan virus for windows distributions. 

Running:(AT YOU OWN RISK), 
in order to deploy the virus on to the computer, run the .exe file
